# NEXUS CITY — Shape the Future

City-building and management game in 3D for mobile browsers and GitHub Pages.

## V4 — New title screen
- New game identity: **NEXUS CITY**.
- Cinematic welcome screen with neon skyline, bold title, and PLAY GAME / ENTER CITY buttons.
- The city simulation starts when the player enters the game.

## Gameplay
- Place houses, apartments, towers, luxury homes, shops, factories, roads, parks, schools, clinics, police, fire stations, power plants and water pumps.
- Residents arrive and leave according to housing, utilities, road access, jobs, happiness and taxes.
- Residents display needs and feedback.
- Monthly rent, taxes, income, upkeep and utility expenses.
- Individual tax rates for residential, commercial, industrial, electricity, water and public services (0–30%).
- Game speed ×1, ×2, ×4 and ×8, plus pause.
- Animated cars and pedestrians; 3D orbit camera and local save.

## Publish on GitHub Pages
1. Create a GitHub repository.
2. Upload `index.html` to the repository root.
3. Open **Settings → Pages**.
4. Select **Deploy from a branch**, branch `main`, folder `/ (root)`.
5. Open the Pages URL in Safari.

Three.js is loaded from jsDelivr, so an internet connection is needed.
